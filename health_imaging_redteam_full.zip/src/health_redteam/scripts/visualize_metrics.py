import os
import pandas as pd
import matplotlib.pyplot as plt
from ..config import CONFIG


def _bar_plot(df, metric, ylabel, filename):
    plt.figure()
    x = df['scenario_type']
    y = df[metric]
    plt.bar(x, y)
    plt.xticks(rotation=45, ha='right')
    plt.ylabel(ylabel)
    plt.title(f'{ylabel} by Scenario Type')
    plt.tight_layout()
    out_path = os.path.join(CONFIG.output_dir, filename)
    plt.savefig(out_path)
    plt.close()


def main():
    summary_path = os.path.join(CONFIG.output_dir, 'summary_metrics.csv')
    if not os.path.exists(summary_path):
        raise FileNotFoundError('Run experiment first')
    df = pd.read_csv(summary_path)
    _bar_plot(df, 'accuracy', 'Accuracy', 'scenario_accuracy.png')

if __name__ == '__main__':
    main()
