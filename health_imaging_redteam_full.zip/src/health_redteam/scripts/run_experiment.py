from ..config import CONFIG
from ..models.dummy import DummyClinicalModel, SimpleHeuristicCritic
from ..eval.experiment import run_experiment

def main():
    clinical = DummyClinicalModel()
    critic = SimpleHeuristicCritic()
    run_experiment(CONFIG, clinical_model=clinical, critic_model=critic)

if __name__ == '__main__':
    main()
