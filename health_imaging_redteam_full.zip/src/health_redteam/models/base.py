from typing import Dict, Any
from ..corruptions import Scenario

class ClinicalModel:
    def answer_case(self, case: Scenario) -> Dict[str, Any]:
        raise NotImplementedError

class CriticModel:
    def score_answer(self, case: Scenario, model_output: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError
