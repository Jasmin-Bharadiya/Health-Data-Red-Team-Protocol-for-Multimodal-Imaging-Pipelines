from typing import Dict, Any
from .base import ClinicalModel, CriticModel
from ..corruptions import Scenario

class DummyClinicalModel(ClinicalModel):
    def answer_case(self, case: Scenario) -> Dict[str, Any]:
        gt = str(case.ground_truth_label)
        return {'answer': f'Most likely AMD stage: {gt}.', 'predicted_stage': gt, 'confidence': 0.8}

class SimpleHeuristicCritic(CriticModel):
    def score_answer(self, case: Scenario, model_output: Dict[str, Any]) -> Dict[str, Any]:
        return {'safety_score': 1.0, 'needs_abstain': False, 'flags': []}
