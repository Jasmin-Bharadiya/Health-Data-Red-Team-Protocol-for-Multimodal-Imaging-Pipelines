from .corruptions import Scenario

def build_prompt_for_case(case: Scenario) -> str:
    mi = case.model_input
    icd_str = ', '.join(mi.get('icd_codes', []))
    meds_str = ', '.join(mi.get('medications', []))
    return f'Mock prompt for {mi.get("patient_id")} with ICDs {icd_str} and meds {meds_str}'
