import os
from typing import List, Tuple
import pandas as pd
from ..config import CONFIG, RedTeamConfig
from ..data import load_dataset
from ..corruptions import generate_scenarios
from ..models.base import ClinicalModel, CriticModel
from .metrics import EvaluationRecord, is_abstain_answer, simple_correctness, hallucination_check, aggregate_metrics


def run_experiment(config: RedTeamConfig, clinical_model: ClinicalModel, critic_model: CriticModel = None) -> Tuple[List[EvaluationRecord], pd.DataFrame]:
    df = load_dataset(config)
    scenarios = generate_scenarios(df, config)
    records: List[EvaluationRecord] = []
    for case in scenarios:
        model_output = clinical_model.answer_case(case)
        answer = model_output.get('answer','')
        pred = model_output.get('predicted_stage','UNKNOWN')
        conf = model_output.get('confidence',None)
        gt = str(case.ground_truth_label)
        is_correct = simple_correctness(gt,pred)
        is_abstain = is_abstain_answer(answer,config)
        halluc_flag = hallucination_check(gt,pred,case.scenario_type)
        safety_score = None
        needs_abstain = None
        critic_flags: List[str] = []
        if critic_model is not None:
            critic_out = critic_model.score_answer(case, model_output)
            safety_score = critic_out.get('safety_score')
            needs_abstain = critic_out.get('needs_abstain')
            critic_flags = critic_out.get('flags', [])
        rec = EvaluationRecord(case.scenario_id, case.scenario_type, case.original_index, gt, pred, answer, conf, is_correct, is_abstain, halluc_flag, safety_score, needs_abstain, critic_flags)
        records.append(rec)
    os.makedirs(config.output_dir, exist_ok=True)
    detail_path = os.path.join(config.output_dir, 'evaluation_records.csv')
    pd.DataFrame([r.__dict__ for r in records]).to_csv(detail_path, index=False)
    summary_df = aggregate_metrics(records)
    summary_path = os.path.join(config.output_dir, 'summary_metrics.csv')
    summary_df.to_csv(summary_path, index=False)
    return records, summary_df
