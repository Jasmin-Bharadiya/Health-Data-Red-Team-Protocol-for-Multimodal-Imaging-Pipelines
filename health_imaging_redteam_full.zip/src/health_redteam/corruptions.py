from dataclasses import dataclass
from typing import Any, Dict, List
import random, os
import numpy as np
import pandas as pd
from .config import CONFIG, RedTeamConfig

class ScenarioType:
    CLEAN='clean'
    MISSING_METADATA='missing_metadata'
    LATERALITY_MISMATCH='laterality_mismatch'
    ICD_CONFLICT='icd_conflict'
    MED_CONFLICT='med_conflict'
    LOW_QUALITY='low_quality'

@dataclass
class Scenario:
    scenario_id: str
    scenario_type: str
    original_index: int
    corruption_details: Dict[str, Any]
    model_input: Dict[str, Any]
    ground_truth_label: Any


def _base_model_input(row: pd.Series) -> Dict[str, Any]:
    return {
        'patient_id': row['patient_id'],
        'eye_id': row['eye_id'],
        'laterality': row['laterality'],
        'image_path': row['image_path'],
        'visit_date': row['visit_date'],
        'icd_codes': row['icd_codes'],
        'medications': row['medications'],
        'image_quality': row.get('image_quality', None),
    }


def _make_clean_scenario(idx, row):
    return Scenario(f'{idx}_clean', ScenarioType.CLEAN, idx, {}, _base_model_input(row), row['amd_stage_label'])


def generate_scenarios(df: pd.DataFrame, config: RedTeamConfig = CONFIG) -> List[Scenario]:
    os.makedirs(config.output_dir, exist_ok=True)
    random.seed(config.seed)
    np.random.seed(config.seed)
    df_sampled = df.sample(n=min(config.n_samples,len(df)), random_state=config.seed).reset_index(drop=True)
    scenarios: List[Scenario] = []
    for i,row in df_sampled.iterrows():
        scenarios.append(_make_clean_scenario(i,row))
    return scenarios
