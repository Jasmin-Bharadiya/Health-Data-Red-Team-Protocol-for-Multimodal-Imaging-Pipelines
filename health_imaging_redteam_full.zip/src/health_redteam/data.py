import json
from typing import Any, List
import pandas as pd
from .config import RedTeamConfig

REQUIRED_COLUMNS = ['patient_id','eye_id','laterality','image_path','visit_date','icd_codes','medications','amd_stage_label']

def load_dataset(config: RedTeamConfig) -> pd.DataFrame:
    path = config.data_path
    if path.endswith('.csv'):
        df = pd.read_csv(path)
    else:
        raise ValueError('Only CSV supported in demo')
    for col in REQUIRED_COLUMNS:
        if col not in df.columns:
            raise ValueError(f'Missing required column: {col}')
    for col in ['icd_codes','medications']:
        if df[col].dtype == object:
            df[col] = df[col].apply(_safe_parse_list)
    return df

def _safe_parse_list(x: Any) -> List[str]:
    if isinstance(x, list):
        return [str(v) for v in x]
    if pd.isna(x):
        return []
    s = str(x)
    try:
        val = json.loads(s)
        if isinstance(val, list):
            return [str(v) for v in val]
    except json.JSONDecodeError:
        pass
    return [v.strip() for v in s.split(',') if v.strip()]
