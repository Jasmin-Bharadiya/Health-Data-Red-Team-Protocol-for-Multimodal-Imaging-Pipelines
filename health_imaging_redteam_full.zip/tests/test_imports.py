def test_imports():
    import health_redteam
    from health_redteam.config import CONFIG
