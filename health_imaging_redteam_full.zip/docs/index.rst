Health Imaging Red-Team Framework
=================================
