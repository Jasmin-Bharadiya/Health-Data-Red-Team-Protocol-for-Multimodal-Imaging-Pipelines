project='Health Imaging Red-Team Framework'
extensions=['sphinx.ext.autodoc']
